# FORTSILV — projeto inicial para Vercel

## Estrutura
- `index.html`: biblioteca (área de visualização).
- `admin.html`: painel administrativo demonstrativo.
- `css/estilo.css`: identidade visual azul-marinho e dourado.
- `js/aluno.js`: renderização da biblioteca.
- `js/admin.js`: cadastro demonstrativo de aulas.
- `vercel.json`: rota `/admin` para o painel.

## Publicar na Vercel
1. Extraia o ZIP.
2. Envie a pasta `FORTSILV_Vercel` para um repositório GitHub.
3. Na Vercel, escolha **Add New → Project** e importe o repositório.
4. Framework Preset: **Other**.
5. Build Command: deixe vazio.
6. Output Directory: `.` (raiz do projeto).
7. Clique em Deploy.

Depois do deploy:
- Biblioteca: `https://SEU-PROJETO.vercel.app/`
- Painel demonstrativo: `https://SEU-PROJETO.vercel.app/admin`

## IMPORTANTE — limites desta versão
Este pacote é uma base visual estática para validar o layout e a navegação. O cadastro de aulas usa `localStorage`, portanto os dados ficam apenas no navegador/dispositivo em que foram cadastrados. O seletor de arquivo apenas seleciona um arquivo local: **não faz upload para a internet**.

Não há autenticação real nem proteção de administrador nesta versão. A rota `/admin` não deve ser considerada privada. Não coloque dados sensíveis ou vídeos privados nela.

## Próxima etapa para tornar o FORTSILV real
Precisaremos conectar:
1. Autenticação (por exemplo, Supabase Auth), com usuários autorizados manualmente.
2. Banco de dados para cursos, módulos, aulas e materiais.
3. Hospedagem/transmissão de vídeo apropriada para vídeos longos (por exemplo, Cloudflare Stream ou Bunny Stream). O plano gratuito da Vercel não é um serviço de hospedagem de videoaulas.
4. Regras de segurança no banco/armazenamento para que somente usuários autenticados autorizados vejam o conteúdo e somente o administrador gerencie.

Não é necessário comprar domínio para testar: a Vercel fornece um endereço `vercel.app`.
